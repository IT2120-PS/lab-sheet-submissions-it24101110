setwd("C:\\Users\\rehan\\Desktop\\IT24101110  Lab10")

observed <- c(120, 95, 85, 100)
chisq.test(observed)
